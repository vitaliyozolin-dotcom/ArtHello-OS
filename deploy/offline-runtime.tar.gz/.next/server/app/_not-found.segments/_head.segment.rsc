1:"$Sreact.fragment"
2:I[9084,[],"ViewportBoundary"]
3:I[9084,[],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[3533,[],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Школа 1–11"}],["$","meta","1",{"name":"description","content":"Боевой учебный модуль ArtHello OS: расписание, журнал, задания, календарь, семьи и школьная жизнь."}],["$","link","2",{"rel":"shortcut icon","href":"/school-logo.svg"}],["$","link","3",{"rel":"icon","href":"/school-logo.svg"}],["$","$L5","4",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"odgg_3DUdKl_gJV9ny2kT"}
