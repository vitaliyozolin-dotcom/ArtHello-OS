1:"$Sreact.fragment"
2:I[3465,[],""]
3:I[3924,["748","static/chunks/748-0f230f3c63c9cf09.js","39","static/chunks/app/error-5112b2bdf98e18ed.js"],"default"]
4:I[2349,[],""]
:HL["/_next/static/css/653e9d98607e4cc3.css","style"]
0:{"rsc":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/653e9d98607e4cc3.css","precedence":"next"}]],["$","html",null,{"lang":"ru","children":["$","body",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$3","errorStyles":[],"errorScripts":[],"template":["$","$L4",null,{}]}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"odgg_3DUdKl_gJV9ny2kT"}
