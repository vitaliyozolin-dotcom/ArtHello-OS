1:"$Sreact.fragment"
2:I[3465,[],""]
3:I[3924,["748","static/chunks/748-0f230f3c63c9cf09.js","39","static/chunks/app/error-5112b2bdf98e18ed.js"],"default"]
4:I[2349,[],""]
5:I[8032,[],"ClientPageRoot"]
6:I[1465,["980","static/chunks/980-52d4259e506f3e95.js","70","static/chunks/app/activate/page-b3dd72bdff8c4bab.js"],"default"]
9:I[9084,[],"OutletBoundary"]
a:"$Sreact.suspense"
d:I[9084,[],"ViewportBoundary"]
f:I[9084,[],"MetadataBoundary"]
11:I[6827,[],"default",1]
:HL["/_next/static/css/653e9d98607e4cc3.css","style"]
0:{"P":null,"c":["","activate"],"q":"","i":false,"f":[[["",{"children":["activate",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",16],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/653e9d98607e4cc3.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"ru","children":["$","body",null,{"children":["$","$L2",null,{"parallelRouterKey":"children","error":"$3","errorStyles":[],"errorScripts":[],"template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],{"children":[["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":[["$","$1","c",{"children":[["$","$L5",null,{"Component":"$6","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@7","$@8"]}}],null,["$","$L9",null,{"children":["$","$a",null,{"name":"Next.MetadataOutlet","children":"$@b"}]}]]}],{},null,false,null]},null,false,"$@c"]},null,false,null],["$","$1","h",{"children":[null,["$","$Ld",null,{"children":"$Le"}],["$","div",null,{"hidden":true,"children":["$","$Lf",null,{"children":["$","$a",null,{"name":"Next.Metadata","children":"$L10"}]}]}],null]}],false]],"m":"$undefined","G":["$11",[]],"S":true,"h":null,"s":"$undefined","l":"$undefined","p":"$undefined","d":"$undefined","b":"odgg_3DUdKl_gJV9ny2kT"}
12:[]
c:"$W12"
7:{}
8:"$0:f:0:1:1:children:1:children:0:props:children:0:props:serverProvidedParams:params"
e:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
13:I[3533,[],"IconMark"]
b:null
10:[["$","title","0",{"children":"Школа 1–11"}],["$","meta","1",{"name":"description","content":"Боевой учебный модуль ArtHello OS: расписание, журнал, задания, календарь, семьи и школьная жизнь."}],["$","link","2",{"rel":"shortcut icon","href":"/school-logo.svg"}],["$","link","3",{"rel":"icon","href":"/school-logo.svg"}],["$","$L13","4",{}]]
