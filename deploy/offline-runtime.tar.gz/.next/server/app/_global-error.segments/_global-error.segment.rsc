1:"$Sreact.fragment"
2:I[3465,[],""]
3:I[2349,[],""]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"odgg_3DUdKl_gJV9ny2kT"}
