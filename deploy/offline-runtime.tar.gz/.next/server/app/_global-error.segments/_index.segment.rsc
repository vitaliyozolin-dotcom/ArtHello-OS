1:"$Sreact.fragment"
2:I[3465,[],""]
3:I[3924,["748","static/chunks/748-0f230f3c63c9cf09.js","39","static/chunks/app/error-5112b2bdf98e18ed.js"],"default"]
4:I[2349,[],""]
5:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","error":"$3","errorStyles":[],"errorScripts":[],"template":["$","$L4",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W5","buildId":"odgg_3DUdKl_gJV9ny2kT"}
