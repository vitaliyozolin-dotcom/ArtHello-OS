1:"$Sreact.fragment"
2:I[1859,["980","static/chunks/980-52d4259e506f3e95.js","748","static/chunks/748-0f230f3c63c9cf09.js","948","static/chunks/948-2eea5633a8a40685.js","974","static/chunks/app/page-ab05df62d98da7a1.js"],"default"]
3:I[9084,[],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","$L2",null,{}],null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"odgg_3DUdKl_gJV9ny2kT"}
5:null
